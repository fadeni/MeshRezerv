# bot/auth.py

import os
import json
import logging
from cryptography.fernet import Fernet
from octodiary.apis import AsyncMobileAPI
from octodiary.urls import Systems
from .database import get_db_connection
from config.settings import ENCRYPTION_KEY_PATH

logger = logging.getLogger(__name__)

# Настройки шифрования
def get_cipher_suite():
    if os.path.exists(ENCRYPTION_KEY_PATH):
        with open(ENCRYPTION_KEY_PATH, 'rb') as f:
            key = f.read()
    else:
        key = Fernet.generate_key()
        with open(ENCRYPTION_KEY_PATH, 'wb') as f:
            f.write(key)
    cipher_suite = Fernet(key)
    return cipher_suite

cipher_suite = get_cipher_suite()

def encrypt_token(token_data):
    token_json = json.dumps(token_data).encode()
    encrypted_token = cipher_suite.encrypt(token_json)
    return encrypted_token

def decrypt_token(encrypted_token):
    decrypted_token = cipher_suite.decrypt(encrypted_token)
    token_data = json.loads(decrypted_token.decode())
    return token_data

def save_token_db(telegram_user_id, encrypted_token):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        REPLACE INTO users (telegram_user_id, encrypted_token)
        VALUES (?, ?)
    ''', (telegram_user_id, encrypted_token))
    conn.commit()
    conn.close()

def load_token_db(telegram_user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT encrypted_token FROM users WHERE telegram_user_id = ?
    ''', (telegram_user_id,))
    result = cursor.fetchone()
    conn.close()
    if result:
        return result[0]
    return None

# Функции для работы с API и токенами
async def is_user_logged_in(telegram_user_id):
    api = AsyncMobileAPI(system=Systems.MES)
    encrypted_token = load_token_db(telegram_user_id)
    if encrypted_token:
        try:
            token_data = decrypt_token(encrypted_token)
            api.token = token_data
            profiles = await api.get_users_profile_info()
            if profiles:
                return True
        except Exception as e:
            logger.error("Сохраненный токен недействителен для пользователя %s: %s", telegram_user_id, e)
    return False

async def get_api_client(telegram_user_id, username=None, password=None):
    api = AsyncMobileAPI(system=Systems.MES)
    encrypted_token = load_token_db(telegram_user_id)
    if encrypted_token:
        try:
            token_data = decrypt_token(encrypted_token)
            api.token = token_data
            profiles = await api.get_users_profile_info()
            if profiles:
                return api, None
        except Exception as e:
            logger.error("Сохраненный токен недействителен для пользователя %s: %s", telegram_user_id, e)

    if username and password:
        try:
            sms_code_obj = await api.login(username=username, password=password)
            return api, sms_code_obj
        except Exception as e:
            logger.error("Ошибка при авторизации пользователя %s: %s", telegram_user_id, e)
            return None, None
    else:
        return None, None
