import os

# Замените на ваш токен Telegram-бота
TELEGRAM_TOKEN = '7900995488:AAHP-vD0DMqeSQBIvdemyJhKp53xoooag74'

# Путь к базе данных
DATABASE_PATH = 'users.db'

# Путь к файлу ключа шифрования
ENCRYPTION_KEY_PATH = 'encryption.key'

# Настройка уровня логирования
LOGGING_LEVEL = os.getenv('LOGGING_LEVEL', 'INFO')
